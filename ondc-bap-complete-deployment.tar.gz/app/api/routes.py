from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import HTMLResponse
import json
import logging
from datetime import datetime
import uuid

from app.api.health import router as health_router
from app.api.v1.ondc_bap import router as ondc_bap_router

logger = logging.getLogger(__name__)

api_router = APIRouter()
api_router.include_router(health_router)
api_router.include_router(ondc_bap_router)


# ONDC Lookup - Direct access at root level
@api_router.get("/lookup")
async def lookup():
    """
    ONDC Lookup Endpoint
    Returns subscriber information for neo-server.rozana.in
    """
    try:
        # Import settings to get subscriber information
        from app.core.config import settings
        
        # Return subscriber information directly
        result = {
            "subscriber_id": settings.ONDC_SUBSCRIBER_ID,
            "subscriber_url": settings.ONDC_SUBSCRIBER_URL,
            "callback_url": "/on_subscribe",
            "domain": settings.ONDC_DOMAIN,
            "type": settings.ONDC_TYPE,
            "status": "active"
        }
        
        # Add cryptographic keys if available
        try:
            from app.core.ondc_crypto import crypto
            credentials = crypto.load_credentials()
            
            result.update({
                "signing_public_key": credentials["signing_keys"]["public"],
                "encryption_public_key": credentials["encryption_keys"]["public"],
                "unique_key_id": credentials["unique_key_id"]
            })
        except Exception as e:
            logger.warning(f"Could not load cryptographic keys: {str(e)}")
            result["keys_available"] = False
        
        logger.info(f"Lookup result: {json.dumps(result, indent=2)}")
        return result
        
    except Exception as e:
        logger.error(f"Error in lookup endpoint: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail=f"Lookup error: {str(e)}"
        )


# ONDC vlookup - Proper ONDC registry lookup endpoint
@api_router.post("/vlookup")
async def vlookup(request: Request):
    """
    ONDC vlookup Endpoint
    Implements ONDC registry lookup with proper signature verification
    """
    try:
        # Get request body
        body = await request.json()
        logger.info(f"ONDC vlookup request: {json.dumps(body, indent=2)}")
        
        # Validate required fields
        required_fields = ["sender_subscriber_id", "request_id", "timestamp", "signature", "search_parameters"]
        for field in required_fields:
            if field not in body:
                raise HTTPException(
                    status_code=400,
                    detail=f"Missing required field: {field}"
                )
        
        # Extract fields
        sender_subscriber_id = body["sender_subscriber_id"]
        request_id = body["request_id"]
        timestamp = body["timestamp"]
        signature = body["signature"]
        search_parameters = body["search_parameters"]
        
        # Validate search parameters
        required_search_fields = ["country", "domain", "type", "city", "subscriber_id"]
        for field in required_search_fields:
            if field not in search_parameters:
                raise HTTPException(
                    status_code=400,
                    detail=f"Missing required search parameter: {field}"
                )
        
        # Create signature verification string
        # Format: country|domain|type|city|subscriber_id
        signature_data = f"{search_parameters['country']}|{search_parameters['domain']}|{search_parameters['type']}|{search_parameters['city']}|{search_parameters['subscriber_id']}"
        
        logger.info(f"Signature data to verify: {signature_data}")
        logger.info(f"Received signature: {signature}")
        
        # For now, we'll return a mock response
        # In production, you would verify the signature and query the actual registry
        
        # Mock response for neo-server.rozana.in lookup
        if search_parameters["subscriber_id"] == "neo-server.rozana.in":
            response = {
                "message": {
                    "ack": {
                        "status": "ACK"
                    }
                },
                "data": {
                    "subscriber_id": "neo-server.rozana.in",
                    "subscriber_url": "https://neo-server.rozana.in",
                    "callback_url": "/on_subscribe",
                    "domain": "nic2004:52110",
                    "type": "buyerApp",
                    "status": "active",
                    "signing_public_key": "QfhgZ30kF6m6aj6gjpvFl2NsdSaV2AfGDNvs9Sqbdl0=",
                    "encryption_public_key": "MCowBQYDK2VuAyEAYyPyJR9s9pzfzVPY0+P/X4mxPKPvS5RnGgFkqSLc+mM=",
                    "unique_key_id": "key_1755737751"
                }
            }
        else:
            # Return empty result for other subscribers
            response = {
                "message": {
                    "ack": {
                        "status": "ACK"
                    }
                },
                "data": None
            }
        
        logger.info(f"ONDC vlookup response: {json.dumps(response, indent=2)}")
        return response
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error in vlookup endpoint: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail=f"vlookup error: {str(e)}"
        )


# ONDC Site Verification - must be at root level for ONDC registry
@api_router.get("/ondc-site-verification.html", response_class=HTMLResponse)
async def site_verification():
    """
    ONDC Site Verification Page
    Required by ONDC registry for domain verification
    """
    try:
        # Try to read the generated verification file
        with open("ondc-site-verification.html", 'r') as f:
            content = f.read()
        return HTMLResponse(content=content)
    except FileNotFoundError:
        # Return a default verification page if file doesn't exist
        return HTMLResponse(content="""
<html>
    <head>
        <meta name='ondc-site-verification' content='not_generated' />
    </head>
    <body>
        ONDC Site Verification Page
        <br>
        <strong>Note:</strong> Generate ONDC keys first to create proper verification file.
        <br>
        Subscriber ID: neo-server.rozana.in
    </body>
</html>
        """)

